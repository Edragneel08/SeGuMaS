/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MODEL;

/**
 *
 * @author edrag
 */
public class guardFamilyDetails {
    
    private String guardID;
    private String maritalStatus;
    private String guardSpName;
    private String guardFamOccu;
    private String guardFamNoP1;
    private String guardNumOfChild;
    private String guardSpAdd;
    private String guardFN;
    private String guardFOccu;
    private String guardMomName;
    private String guardMomOccu;
    private String guardParentAdd;

    public guardFamilyDetails(String guardID, String maritalStatus, String guardSpName, String guardFamOccu, String guardFamNoP1, String guardNumOfChild, String guardSpAdd, String guardFN, String guardFOccu, String guardMomName, String guardMomOccu, String guardParentAdd) {
        this.guardID = guardID;
        this.maritalStatus = maritalStatus;
        this.guardSpName = guardSpName;
        this.guardFamOccu = guardFamOccu;
        this.guardFamNoP1 = guardFamNoP1;
        this.guardNumOfChild = guardNumOfChild;
        this.guardSpAdd = guardSpAdd;
        this.guardFN = guardFN;
        this.guardFOccu = guardFOccu;
        this.guardMomName = guardMomName;
        this.guardMomOccu = guardMomOccu;
        this.guardParentAdd = guardParentAdd;
    }

    public guardFamilyDetails(String guardID) {
        this.guardID = guardID;
    }


    public String getGuardID() {
        return guardID;
    }

    public void setGuardID(String guardID) {
        this.guardID = guardID;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }
    
    public String getGuardSpName() {
        return guardSpName;
    }

    public void setGuardSpName(String guardSpName) {
        this.guardSpName = guardSpName;
    }

    public String getGuardFamOccu() {
        return guardFamOccu;
    }

    public void setGuardFamOccu(String guardFamOccu) {
        this.guardFamOccu = guardFamOccu;
    }

    public String getGuardFamNoP1() {
        return guardFamNoP1;
    }

    public void setGuardFamNoP1(String guardFamNoP1) {
        this.guardFamNoP1 = guardFamNoP1;
    }

    public String getGuardNumOfChild() {
        return guardNumOfChild;
    }

    public void setGuardNumOfChild(String guardNumOfChild) {
        this.guardNumOfChild = guardNumOfChild;
    }

    public String getGuardSpAdd() {
        return guardSpAdd;
    }

    public void setGuardSpAdd(String guardSpAdd) {
        this.guardSpAdd = guardSpAdd;
    }

    public String getGuardFN() {
        return guardFN;
    }

    public void setGuardFN(String guardFN) {
        this.guardFN = guardFN;
    }

    public String getGuardFOccu() {
        return guardFOccu;
    }

    public void setGuardFOccu(String guardFOccu) {
        this.guardFOccu = guardFOccu;
    }

    public String getGuardMomName() {
        return guardMomName;
    }

    public void setGuardMomName(String guardMomName) {
        this.guardMomName = guardMomName;
    }

    public String getGuardMomOccu() {
        return guardMomOccu;
    }

    public void setGuardMomOccu(String guardMomOccu) {
        this.guardMomOccu = guardMomOccu;
    }

    public String getGuardParentAdd() {
        return guardParentAdd;
    }

    public void setGuardParentAdd(String guardParentAdd) {
        this.guardParentAdd = guardParentAdd;
    }

    public String getguardID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}

